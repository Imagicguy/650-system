from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Integer,Table,ForeignKey,Float
from sqlalchemy.orm import sessionmaker

engine = create_engine('postgresql://postgres:passw0rd@localhost:5432/acc_bball')

Session = sessionmaker(bind=engine)
sb = Session()

Base = declarative_base()

class State(Base):
    __tablename__ = 'state'

    state_id = Column(Integer,primary_key= True)
    name = Column(String(64))

class Color(Base):
    __tablename__ = 'color'

    color_id = Column(Integer,primary_key=True)
    name = Column(String(64))

class Team(Base):

    __tablename__ = 'team'

    team_id = Column(Integer,primary_key=True)
    losses = Column(Integer)
    wins = Column(Integer)
    color_id = Column(Integer,ForeignKey('color.color_id'))
    state_id = Column(Integer,ForeignKey('state.state_id'))
    name = Column(String(64))
    
class Player(Base):
    __tablename__  = 'player'

    player_id  =Column(Integer,primary_key= True)
    team_id = Column(Integer,ForeignKey('team.team_id'))
    uniform_num = Column(Integer)
    first_name = Column(String(64))
    last_name = Column(String(64))
    mpg = Column(Integer)
    ppg = Column(Integer)
    rpg = Column(Integer)
    apg = Column(Integer)
    spg = Column(Float)
    bpg = Column(Float)



def query1(use_mpg,min_mpg,max_mpg,use_ppg,min_ppg,max_ppg,use_rpg,min_rpg,max_rpg,use_apg,min_apg,max_apg,use_spg,min_spg,max_spg,use_bpg,min_bpg,max_bpg):
    query1 = sb.query(Player)
    if use_mpg:
        query1 = query1.filter(Player.mpg >= min_mpg,Player.mpg <= max_mpg )
    if use_ppg:
        query1 = query1.filter(Player.ppg >= min_ppg,Player.ppg <= max_ppg )
    if use_rpg:
        query1 = query1.filter(Player.rpg >= min_rpg,Player.rpg <= max_rpg )
    if use_apg:
        query1 = query1.filter(Player.apg >= min_apg,Player.apg <= max_apg )
    if use_spg:
        query1 = query1.filter(Player.spg >= min_spg,Player.spg <= max_spg )
    if use_bpg:
        query1 = query1.filter(Player.bpg >= min_bpg,Player.bpg <= max_bpg )

    print("PLAYER_ID TEAM_ID UNIFORM_NUM FIRST_NAME LAST_NAME MPG PPG RPG APG SPG BPG")
    
    for i in query1:
        print(i.player_id,i.team_id,i.uniform_num,i.first_name,i.last_name,i.mpg,i.ppg,i.rpg,i.apg,i.spg,i.bpg)
    

def query2(team_color):
    query2 = sb.query(Team,Color)
    query2 = query2.filter(Team.color_id == Color.color_id,Color.name == team_color)
    print("NAME")
    for i in query2:
        print(i.Team.name)


def query3(team_name):
    query3 = sb.query(Player,Team)
    query3 = query3.filter(Player.team_id == Team.team_id,Team.name == team_name).order_by(Player.ppg.desc())
    print("FIRST_NAME LAST_NAME")
    for i in query3:
        print(i.Player.first_name,i.Player.last_name)

def query4(team_state,team_color):
    query4 = sb.query(Player,Team,State,Color)
    query4 = query4.filter(Player.team_id == Team.team_id,Team.state_id == State.state_id,Team.color_id == Color.color_id,Color.name == team_color,State.name == team_state)
    print("FIRST_NAME LAST_NAME UNIFORM_NUM")
    for i in query4:
        print(i.Player.first_name,i.Player.last_name,i.Player.uniform_num)

def query5(num_wins):
    query5 = sb.query(Player,Team)
    query5 = query5.filter(Player.team_id == Team.team_id,Team.wins > num_wins)
    print("FIRST_NAME LAST_NAME NAME WINS")
    for i in query5:
        print(i.Player.first_name,i.Player.last_name,i.Team.name,Team.wins)

query1(1, 24, 100, 0, 20, 100, 0, 10, 0, 2, 0, 13, 0, 12, 0, 1, 1, 3)
query2("LightBlue")
query2( "Orange");
query3( "Duke");
query3( "NCSU");
query3( "BUAAISBEST!");
query4( "NC", "Orange");
query4("NC","LightBlue");
query5( 21);
query5(17);

    
